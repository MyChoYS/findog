

class lostdoglist :
    def __init__(self, i_dogid, i_id, i_dogbreed, i_title, i_findplace, i_Lat, i_Ion, i_cellphone, i_explanation, i_img, i_findtime):
        self.i_dogid = i_dogid;
        self.i_id = i_id
        self.i_dogbreed = i_dogbreed
        self.i_title = i_title
        self.i_findplace = i_findplace
        self.i_Lat = i_Lat
        self.i_Ion = i_Ion
        self.i_cellphone = i_cellphone
        self.i_explanation = i_explanation
        self.i_img = i_img
        self.i_findtime = i_findtime