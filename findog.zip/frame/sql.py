

class Sql :
    selectall = "SELECT * FROM lostdoglist";
    selectbyid = "SELECT * FROM lostdoglist where dogid = %d";