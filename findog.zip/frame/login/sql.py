

class Sql :
    memberinsert = "INSERT INTO member VALUE('%s', '%s', '%s', '%s', '%s') ";
    selectid = "SELECT * FROM member WHERE member_id='%s'";

